 <!-- NAVBAR -->
 <nav class="navbar navbar-expand-lg fixed-top navbar-custom sticky">
     <div class="container">

         <a class="navbar-brand logo" href="#">smpn 1 selemadeg timur</a>
         <button class="navbar-toggler collapsed" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
             <i class="mdi mdi-menu"></i>
         </button>
         <div class="collapse navbar-collapse" id="navbarNav">
             <ul class="navbar-nav ml-auto">
                 <li class="nav-item active">
                     <a class="nav-link" href="#home">Home</a>
                 </li>
                 <li class="nav-item">
                     <a class="nav-link" href="#blog">Blog</a>
                 </li>
                 <!-- <li class="nav-item">
                     <a class="nav-link" href="#service">Services</a>
                 </li> -->
                 <li class="nav-item">
                     <a class="nav-link" href="#portfolio">Ekstrakulikuler</a>
                 </li>
                 <li class="nav-item">
                     <a class="nav-link" href="#client">Clients</a>
                 </li>
                 <li class="nav-item">
                     <a class="nav-link" href="#team">Team</a>
                 </li>

                 <li class="nav-item">
                     <a class="nav-link" href="#contact">Contact</a>
                 </li>
             </ul>
         </div>
     </div>
 </nav>
 <!-- NAVBAR END-->