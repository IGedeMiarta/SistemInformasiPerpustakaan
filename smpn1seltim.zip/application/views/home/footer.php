<!-- JAVASCRIPTS -->
<script src="<?= base_url() . 'assets/borial/js/jquery.min.js' ?>"></script>
<!-- SCROLL -->
<script src="<?= base_url() . 'assets/borial/js/scrollspy.min.js' ?>"></script>
<!--  -->
<script src="<?= base_url() . 'assets/borial/js/popper.min.js' ?>"></script>
<!-- bootstrap -->
<script src="<?= base_url() . 'assets/borial/js/bootstrap.min.js' ?>"></script>
<!-- easing -->
<script src="<?= base_url() . 'assets/borial/js/jquery.easing.min.js' ?>"></script>
<!-- Portfolio -->
<script src="<?= base_url() . 'assets/borial/js/jquery.magnific-popup.min.js' ?>"></script>
<script src="<?= base_url() . 'assets/borial/js/isotope.js' ?>"></script>
<!-- scroll -->
<script src="<?= base_url() . 'assets/borial/js/scrollspy.min.js' ?>"></script>
<!-- Counter -->
<script src="<?= base_url() . 'assets/borial/js/jquery.counterup.min.js' ?>"></script>
<!-- Owl Carousel -->
<script src="<?= base_url() . 'assets/borial/js/owl.carousel.min.js' ?>"></script>
<!-- Custom -->
<script src="<?= base_url() . 'assets/borial/js/app.js' ?>"></script>

</body>

</html>